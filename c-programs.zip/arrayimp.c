#include<stdio.h>
#include<stdlib.h>
int main()
{
  int a[20],n,i,j,dist;
  printf("enter the size of the array\n");
  scanf("%d",&n);
  printf("enter the elements of the array (should not have a 0\n");
  for (i=0;i<n;i++)
  scanf("%d",&a[i]);
  for (i=0;i<n-1;i++)
  {
    for (j=i+1;j<n;j++)
    {
      if (a[i]==(abs(a[j]))&&a[i]+a[j]==0)
      dist=dist+1;
    }
  }
  printf("the distinct values are %d\n",dist);
}
