#include<stdio.h>
int main()
{
  int a[20],n,i,j,temp;
  printf("enter the size of the array\n");
  scanf("%d",&n);
  printf("enter the elements of the array\n");
  for (i=0;i<n;i++)
  scanf("%d",&a[i]);
  printf("the elements before sorting is\n");
  for (i=0;i<n;i++)
  printf("%d\n", a[i]);
  for (i=0;i<n-1;i++)
  {
    for (j=0;j<n-1-i;j++)
    {
      if (a[j]>a[j+1])
      {
        temp=a[j];
        a[j]=a[j+1];
        a[j+1]=temp;
      }
    }
  }
printf("the elements after sorting are\n");
for (i=0;i<n;i++)
printf("%d\n",a[i]);
return 0;
}