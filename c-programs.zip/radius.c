//program to find radius and circumference//
#include<stdio.h>
int main()
 {
	float radius, area, circumference;
	printf("\nEnter the radius of Circle : ");
	scanf("%f", &radius);
	area = 3.14 * radius * radius;
	printf("\nArea of Circle : %f", area);
  circumference = 2 * 3.14 * radius;
  printf("\nCircumference of circle : %f", circumference);
	return 0;
}