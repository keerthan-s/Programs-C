#include<stdio.h>
int main()
{
int x;
  x=4>8?5!= 1<5==0?1:2:3;
  printf("%d",x);
  return 0;
  }
  