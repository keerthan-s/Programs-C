//program for a simple calculator//
#include<stdio.h>
int main()
{
  int a,b,result;
  char op;
  printf("Enter two operands\n");
  scanf("%d%d",&a,&b);
  printf("enter operator\n 1)+ for addition\n 2)- for subtraction\n 3)* for product\n 4)/ for quotient\n 5)%% for remainder\n");
  scanf(" %c",&op);
  if(op=='+')
  {
    result=a+b;
    printf("%d+%d=%d\n",a,b,result);
  }
  else if(op=='-')
{
  result=a-b;
  printf("%d-%d=%d\n",a,b,result);
}
else if (op=='*')
{
  result=a*b;
  printf("%d*%d=%d\n",a,b,result);
}
else if (op=='/')
{
  if(b==0)
  {
    printf("divison not possible\n");
    return -1;
  }
  else
  {
    result=a/b;
    printf("after divison quotient=%d\n",result);
  }
}
else if(op=='%')
{
  if(b==0)
  {
    printf("divison not possible\n");
    return -1;
  }
  else
  {
    result=a%b;
    printf("after divison remainder=%d\n",result);
  }
}
    else
    {
      printf("enter correct operator\n");
    }
    return 0;
}

