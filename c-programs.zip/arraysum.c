#include<stdio.h>
int main()
{
  int a[20],n,i,sum;
  printf("enter the size of the array\n");
  scanf("%d",&n);
  printf("enter the elements of the array\n");
  for (i=0;i<n;i++)
  scanf("%d",&a[i]);
  printf("the elements to be added are\n");
  for (i=0;i<n;i++)
  printf("%d\n", a[i]);
  for(i = 0; i < n; i++)
 sum = sum + a[i];
 printf ("sum of the array=%d\n",sum);
}