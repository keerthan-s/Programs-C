//program to find simple interest//
#include <stdio.h>

int main()
{
    float principle, rate, time, SI;

    printf("Enter the principle :");
    scanf("%f", &principle);
    printf("Enter the rate :");
    scanf("%f", &rate);
    printf("Enter the time :");
    scanf("%f", &time);

    SI = principle * rate * time / 100;

    printf("Simple interest is %f", SI);
    return 0;
}