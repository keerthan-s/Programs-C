#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,d,r1,r2,rpart,ipart;
  printf("Enter a,b,c\n");
  scanf("%f%f%f",&a,&b,&c);
  if(a==0)
  {
    printf("equation is linear\n");
  return 1;
  }
  d=(b*b)-(4.0*a*c);
  if (d==0)
  {
    printf("roots real and equal\n");
    r1=r2= -b/(2*a);
    printf("r1=r2=%f\n",r1);
  }
  else if(d>0)
  {
    printf("roots are real and distinct\n");
    r1=(-b+ sqrt(d))/(2*a);
    r2=(-b- sqrt(d))/(2*a);
    printf("r1=%f \n",r1);
    printf("r2=%f\n",r2);
  }
  else
  {
    printf("roots are imaginary\n");
    rpart=-b/(2.0*a);
    ipart=sqrt(-d)/(2.0*a);
    printf("r1=%f+i%f\n",rpart,ipart);
    printf("r2=%f-i%f\n",rpart,ipart);
  }
  return 0;
}
  



  


  

