// C program to find the greatest of two numbers//

#include<stdio.h>
int main()
{
int num1, num2;
printf("enter two numbers\n");
scanf("%d%d",&num1,&num2);
if(num1 > num2)
{ 
printf("%d is greater",num1);
}
else
{
printf("%d is greater",num2);
}
return 0;
}