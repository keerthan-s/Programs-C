#include<stdio.h>
#define meter_charge 100
int main()
{
  float total;
  float units;
  char name[20];
  printf("Enter customer name\n");
  scanf("%s",name);
printf("Enter units\n");
scanf("%f",&units);

if(units<0)
{
  printf("invalid input\n");
return 1;
}

if(units<=200)
{
  total=(units*0.8)+ meter_charge;
}

else if(units<=300)
{
  total=(0.8*200)+(0.9*(units-200)) + meter_charge;
}

else
{
  total=(0.8*200) + (0.9*100)+(1*(units-300)) + meter_charge;
}

if(total>400)
{
  total = total + (total*0.15);
}

printf("\n\nELECTRICITY BILL\n");
printf("----------------\n");
printf("\nName : %s\n",name);
printf("No.of units = %.2f\n",total);
printf("-----------\n");
return 0;
}
