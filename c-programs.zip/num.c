//program to print the greater number//
#include <stdio.h>
int main()
{
  int num1;
  int num2;
  printf("enter the first number:\n");
  scanf("%i",&num1);
  printf("enter the second number:\n");
  scanf("%i",&num2);
  if (num1>num2)
  {
    printf("the greater number is\n");
  printf("%i\n",num1);
  }
  else
  {
printf("the greater number is\n");
    printf("%i\n",num2);
  }
return 0;
}
