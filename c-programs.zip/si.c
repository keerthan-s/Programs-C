
#include <stdio.h>
#include <math.h>
int main( ) {
float p,r,t,si,ci;
printf("Enter principle, rate and time : ");
scanf("%f%f%f", &p, &r, &t);
si=p*r*t/100.00;
ci=p* ((1+r/100/4),(t*4))-p; /* quarterly compounded */
printf("Simple interest = %.2f\n", si);
printf("Compound interest = %.2f\n", ci);
return (0);
}
